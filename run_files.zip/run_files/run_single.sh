#!/bin/bash

# Command to enable modules, and then load an appropriate MP/MPI module
. /etc/profile.d/modules.sh
module load mpi/intel/2016/openmpi-2.0.1
module load compile/intel/2016

# Untar your program installation, if necessary
#tar -xzf Magnetic.tar.gz

# Command to run your OpenMP/MPI program
# (This example uses mpirun, other programs
# may use mpiexec, or other commands)
#mpirun -n 8 /home/jhu238/MUPRO/Main_Programs/Magnetic/MagneticFilmPlate1.0.6/InitialChecker/Magnetic.exe
mpirun -n 16 ./EffProperty.exe



