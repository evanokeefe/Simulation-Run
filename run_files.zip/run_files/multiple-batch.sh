#!/bin/bash
inputFile1="param.in"
inputFile2="parameter.in"
pbsFile1="run_single.sh"
pbsFile2="submit-single.sub"
code="Structure.f90"
Execut1="Structure.out"
Execut2="EffProperty.exe"
numberList=$(echo "for(i=000;i<=200;i=i+10) i" | bc | awk '{printf "%i ",$0}')
for number in $numberList;do
	mkdir number-${number}
	cd number-${number}
	cp ../${inputFile1} .
	sed -i "s/number/${number}/g" ${inputFile1}
	cp ../${inputFile2} .
	cp ../${pbsFile1} .
	cp ../${pbsFile2} .
	cp ../${code} .
	cp ../${Execut2} .
	ifort -o ${Execut1} ${code}
	./${Execut1}
	condor_submit ${pbsFile2}
	cd ..
done
